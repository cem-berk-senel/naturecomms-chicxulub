Fig_5: based on the output of contour_S_impact_Gt070.py (6 subplots)

Fig_S9: based on the output of contour_S_impact_Gt030.py (6 subplots)

Fig_S10: based on the output of contour_S_impact_Gt110.py (6 subplots)

Fig_S11: based on the output of contour_S_impact_Gt200.py (6 subplots)

Fig_S12: based on the output of contour_S_impact_Gt325.py (6 subplots)

Fig_S13: based on the output of contour_S_impact_Gt325.py and contour_S_impact_Gt070.py (3 subplots)

Fig_S14: based on the output of contour_S_local_impact_Gt001.py, contour_S_local_impact_Gt005.py, contour_S_local_impact_Gt070.py (6 subplots)

Any question? Contact me via email: cem.berk@observatory.be
Dr. Cem Berk Senel, FWO Postdoctoral Fellow
AMGC Vrije Universiteit Brussel & Royal Observatory of Belgium
April 04, 2024.
